import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/HeroSection/Header/Header';
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home/Home';
import Footer from './components/Footer/Footer';
import Contract from './components/Contract/Contract';

function App() {
  return (
    <div>
      <Header />
      <Routes>
        <Route path='/' element={<Home />} />
      </Routes>
      <Contract />
      <Footer />
    </div>
  )
}

export default App
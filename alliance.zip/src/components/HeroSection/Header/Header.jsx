import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import Navbar from '../Navbar/Navbar.jsx'
import "./Header.scss"
import HeroSlider from '../HeroSlider/HeroSlider.jsx'
import Advantages from '../Advantages/Advantages.jsx'

function Header() {
  return (
    <header>
      <Navbar />
      <div className="hero">
        <Container>
          <Row>
            <Col md='10'><HeroSlider /></Col>
            <Col xs='auto' className='dn'><Advantages /></Col>
          </Row>
        </Container>
      </div>
    </header>
  )
}

export default Header
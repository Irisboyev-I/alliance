import React from 'react'
import "./Home.scss"
import WorkerScheme from '../../components/WorkerScheme/WorkerScheme'
import ProductCategories from '../../components/ProductCategories/ProductCategories'
import OwnProducts from '../../components/OwnProducts/OwnProducts'
import Relationships from '../../components/Relationships/Relationships'
import Blog from '../../components/Blog/Blog'

function Home() {
    return (
        <div>
            <WorkerScheme />
            <ProductCategories />
            <OwnProducts />
            <Relationships />
            <Blog />
        </div>
    )
}

export default Home